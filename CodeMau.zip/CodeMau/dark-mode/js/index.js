// Gán theme mặc định từ localStorage (nếu có)
const currentTheme = localStorage.getItem('theme') || 'light';
document.documentElement.setAttribute('data-theme', currentTheme);
document.getElementById("modeLabel").textContent = currentTheme === 'dark' ? 'Tối' : 'Sáng';

function toggleTheme() {
  const root = document.documentElement;
  const isDark = root.getAttribute('data-theme') === 'dark';
  const newTheme = isDark ? 'light' : 'dark';
  root.setAttribute('data-theme', newTheme);
  localStorage.setItem('theme', newTheme);
  document.getElementById("modeLabel").textContent = newTheme === 'dark' ? 'Tối' : 'Sáng';
}