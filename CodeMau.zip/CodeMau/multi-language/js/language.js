const translations = {
  en: {
    title: "Welcome",
    description: "This is a multi-language site.",
  },
  vi: {
    title: "Chào mừng",
    description: "Đây là một trang web đa ngôn ngữ.",
  },
};

const languageSelector = document.getElementById("language-selector");

function setLanguage(lang) {
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    el.textContent = translations[lang][key] || key;
  });
}

setLanguage("en");

languageSelector.addEventListener("change", (e) => {
  setLanguage(e.target.value);
});
