// js/favorites.js

const currentUser = JSON.parse(localStorage.getItem('currentUser'));
const favKey = currentUser ? `favorites_${currentUser.id}` : '';

$(document).ready(function() {
    
    // 1. CHECK LOGIN
    if (!currentUser) {
        window.location.href = 'login.html';
        return;
    }
    $('#welcome-name').text(currentUser.name);

    // Xử lý đăng xuất
    $('#btn-logout').click(function(e) {
        e.preventDefault();
        localStorage.removeItem('currentUser');
        window.location.href = 'login.html';
    });

    // 2. LOAD DATA TỪ LOCAL STORAGE
    loadFavorites();

    function loadFavorites() {
        // Lấy mảng favorites từ LocalStorage
        let favorites = JSON.parse(localStorage.getItem(favKey)) || [];
        const listContainer = $('#fav-list');
        const emptyState = $('#empty-state');

        listContainer.empty();

        if (favorites.length === 0) {
            emptyState.removeClass('d-none');
            return;
        } else {
            emptyState.addClass('d-none');
        }

        favorites.forEach((tour, index) => {
            // Lấy ghi chú đã lưu (nếu có)
            const note = tour.userNote || ''; 

            const html = `
                <div class="col-md-4 col-sm-6 mb-4">
                    <div class="card h-100">
                        <div class="position-relative">
                            <img src="${tour.image || 'https://via.placeholder.com/400'}" 
                                 class="card-img-top" 
                                 alt="${tour.title}" 
                                 onerror="this.onerror=null; this.src='https://via.placeholder.com/400'">
                            <span class="btn-fav-card active" data-id="${tour.id}" style="pointer-events: none;">
                                <i class="fas fa-heart"></i>
                            </span>
                        </div>
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">${tour.title}</h5>
                            <div class="tour-meta mb-2">
                                <i class="fas fa-map-marker-alt"></i> ${tour.destination} | 
                                <i class="fas fa-clock"></i> ${tour.duration || 'N/A'} ngày
                            </div>
                            <p class="card-text">${tour.description || ''}</p>
                            <div class="mt-auto">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <span class="price-tag">${parseInt(tour.price).toLocaleString()} VNĐ</span>
                                    <button class="btn btn-primary btn-sm rounded-pill px-3">Chi tiết</button>
                                </div>
                                <div class="note-section">
                                    <textarea class="form-control mb-2 note-input" rows="2" placeholder="Ghi chú (ví dụ: Đi cùng gia đình...)" data-index="${index}">${note}</textarea>
                                    <div class="d-flex gap-2">
                                        <button class="btn btn-sm btn-success btn-save-note flex-grow-1" data-index="${index}">
                                            <i class="fas fa-save"></i> Lưu
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger btn-remove flex-grow-1" data-index="${index}">
                                            <i class="fas fa-trash-alt"></i> Bỏ thích
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            listContainer.append(html);
        });
    }

    // 3. XỬ LÝ LƯU GHI CHÚ
    $(document).on('click', '.btn-save-note', function() {
        const index = $(this).data('index');
        // Tìm ô textarea tương ứng dựa vào index
        const newNote = $(`.note-input[data-index="${index}"]`).val();

        // Cập nhật vào LocalStorage
        let favorites = JSON.parse(localStorage.getItem(favKey)) || [];
        if (favorites[index]) {
            favorites[index].userNote = newNote; // Thêm thuộc tính userNote
            localStorage.setItem(favKey, JSON.stringify(favorites));
            alert("Đã lưu ghi chú!");
        }
    });

    // 4. XỬ LÝ XÓA KHỎI YÊU THÍCH
    $(document).on('click', '.btn-remove', function() {
        if(confirm("Bỏ tour này khỏi danh sách yêu thích?")) {
            const index = $(this).data('index');
            let favorites = JSON.parse(localStorage.getItem(favKey)) || [];
            
            // Xóa phần tử tại vị trí index
            favorites.splice(index, 1);
            
            // Lưu lại và vẽ lại giao diện
            localStorage.setItem(favKey, JSON.stringify(favorites));
            loadFavorites();
        }
    });

});