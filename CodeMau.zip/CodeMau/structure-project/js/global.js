// js/global.js
const API_URL = 'https://693c2c18b762a4f15c3fb6b2.mockapi.io';

// --- 1. TỪ ĐIỂN NGÔN NGỮ (DICTIONARY) ---
const translations = {
    vi: {
        // Login Page
        login_title: "Đăng Nhập",
        signup_title: "Tạo Tài Khoản",
        social_text_signup: "hoặc sử dụng email để đăng ký",
        social_text_login: "hoặc sử dụng tài khoản của bạn",
        placeholder_name: "Tên hiển thị",
        placeholder_email: "Email",
        placeholder_pass: "Mật khẩu",
        btn_signup: "Đăng Ký",
        btn_login: "Đăng Nhập",
        forgot_pass: "Quên mật khẩu?",
        overlay_welcome_back: "Chào bạn cũ!",
        overlay_sub_welcome: "Để tiếp tục kết nối, hãy đăng nhập bằng thông tin cá nhân của bạn",
        overlay_hello: "Xin chào!",
        overlay_sub_hello: "Nhập thông tin cá nhân của bạn và bắt đầu hành trình du lịch cùng chúng tôi",
        btn_ghost_login: "Đăng Nhập Ngay",
        btn_ghost_signup: "Đăng Ký Ngay",
        nav_home: "Trang chủ",
        nav_fav: "Yêu thích",
        nav_logout: "Đăng xuất",
        hero_title: "Khám phá thế giới cùng chúng tôi",
        search_placeholder: "Tìm tên tour...",
        filter_price: "Lọc theo giá",
        filter_all: "Tất cả",
        filter_under_5: "Dưới 5 triệu",
        filter_5_10: "Từ 5 - 10 triệu",
        filter_over_10: "Trên 10 triệu",
        btn_search: "Tìm kiếm",
        btn_add_tour: "Thêm Tour Mới",
        currency: "VNĐ",
        card_duration: "ngày",
        btn_detail: "Chi tiết",
        btn_edit: "Sửa",
        btn_delete: "Xóa",
        modal_add_title: "Thêm Tour Mới",
        modal_edit_title: "Cập Nhật Tour",
        lbl_tour_name: "Tên Tour",
        lbl_destination: "Địa điểm",
        lbl_price: "Giá (VNĐ)",
        lbl_duration: "Thời gian (ngày)",
        lbl_image: "Link Ảnh",
        lbl_desc: "Mô tả",
        btn_save: "Lưu lại",
        btn_close: "Đóng",
        nav_about: "Giới thiệu",
        nav_login: "Đăng nhập",
        lbl_search_name: "Tên tour...",
        lbl_search_duration: "Số ngày...",
        lbl_filter_dest: "Nhập địa điểm...",
        hero_subtitle: "Tìm kiếm theo cách của bạn",
        about_title: "Về Chúng Tôi",
        about_content: "Chúng tôi là nền tảng đặt tour du lịch hàng đầu...",
        msg_login_required: "Vui lòng đăng nhập để sử dụng tính năng này!",
        err_required: "Thông tin này không được để trống",
        err_email_invalid: "Email không đúng định dạng",
        err_pass_short: "Mật khẩu phải có ít nhất 6 ký tự",
        err_email_exists: "Email này đã được sử dụng",
        err_login_fail: "Email hoặc mật khẩu không chính xác",
        err_network: "Lỗi kết nối, vui lòng thử lại sau",
        success_signup: "Đăng ký thành công! Hãy đăng nhập ngay.",
        err_email_not_found: "Email này chưa được đăng ký", // Lỗi khi tìm không thấy email
        err_password_wrong: "Mật khẩu không chính xác",
        
    },
    en: {
        // Login Page
        login_title: "Sign In",
        signup_title: "Create Account",
        social_text_signup: "or use your email for registration",
        social_text_login: "or use your account",
        placeholder_name: "Full Name",
        placeholder_email: "Email",
        placeholder_pass: "Password",
        btn_signup: "Sign Up",
        btn_login: "Sign In",
        forgot_pass: "Forgot your password?",
        overlay_welcome_back: "Welcome Back!",
        overlay_sub_welcome: "To keep connected with us please login with your personal info",
        overlay_hello: "Hello Friend!",
        overlay_sub_hello: "Enter your personal details and start journey with us",
        btn_ghost_login: "Sign In",
        btn_ghost_signup: "Sign Up",
        nav_home: "Home",
        nav_fav: "Favorites",
        nav_logout: "Logout",
        hero_title: "Discover the world with us",
        search_placeholder: "Search tour name...",
        filter_price: "Filter by price",
        filter_all: "All",
        filter_under_5: "Under 5 million",
        filter_5_10: "5 - 10 million",
        filter_over_10: "Over 10 million",
        btn_search: "Search",
        btn_add_tour: "Add New Tour",
        currency: "VND",
        card_duration: "days",
        btn_detail: "Details",
        btn_edit: "Edit",
        btn_delete: "Delete",
        modal_add_title: "Add New Tour",
        modal_edit_title: "Update Tour",
        lbl_tour_name: "Tour Name",
        lbl_destination: "Destination",
        lbl_price: "Price (VND)",
        lbl_duration: "Duration (days)",
        lbl_image: "Image URL",
        lbl_desc: "Description",
        btn_save: "Save",
        btn_close: "Close",
        nav_about: "About Us",
        nav_login: "Login",
        lbl_search_name: "Tour name...",
        lbl_search_duration: "Days...",
        lbl_filter_dest: "Destination...",
        hero_subtitle: "Search your way",
        about_title: "About Us",
        about_content: "We are the leading travel booking platform...",
        msg_login_required: "Please login to use this feature!",
        err_required: "This field is required",
        err_email_invalid: "Invalid email format",
        err_pass_short: "Password must be at least 6 characters",
        err_email_exists: "This email is already taken",
        err_login_fail: "Incorrect email or password",
        err_network: "Network error, please try again later",
        success_signup: "Registration successful! Please login.",
        err_email_not_found: "Email not found",
        err_password_wrong: "Incorrect password",
    }
};

$(document).ready(function() {
    
    // --- 2. XỬ LÝ DARK MODE ---
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    updateThemeIcon(savedTheme);

    $('#theme-toggle').on('click', function() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        updateThemeIcon(newTheme);
    });

    function updateThemeIcon(theme) {
        if(theme === 'dark') {
            $('#theme-toggle').html('<i class="fas fa-sun"></i>'); // Icon mặt trời
        } else {
            $('#theme-toggle').html('<i class="fas fa-moon"></i>'); // Icon mặt trăng
        }
    }

    // --- 3. XỬ LÝ ĐA NGÔN NGỮ ---
    const savedLang = localStorage.getItem('lang') || 'vi';
    $('#language-selector').val(savedLang); // Set giá trị cho select box
    applyLanguage(savedLang);

    $('#language-selector').on('change', function() {
        const lang = $(this).val();
        localStorage.setItem('lang', lang);
        applyLanguage(lang);
    });

    function applyLanguage(lang) {
        $('[data-i18n]').each(function() {
            const key = $(this).data('i18n');
            const text = translations[lang][key];
            
            if (text) {
                // Nếu là thẻ input thì đổi placeholder, ngược lại đổi text
                if ($(this).is('input')) {
                    $(this).attr('placeholder', text);
                } else {
                    $(this).text(text);
                }
            }
        });
    }
});

// Các hàm tiện ích khác (validate, notify...) giữ nguyên như cũ
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}