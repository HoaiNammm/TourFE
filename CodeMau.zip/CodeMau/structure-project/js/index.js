// js/index.js

// --- CẤU HÌNH PHÂN TRANG ---
const ITEMS_PER_PAGE = 6; // Số tour hiện mỗi trang (bạn chỉnh số này nếu muốn)

// --- TRẠNG THÁI (STATE) ---
let allTours = [];             // Chứa tất cả dữ liệu gốc tải từ server
let currentFilteredTours = []; // Chứa danh sách tour sau khi lọc (để phân trang trên danh sách này)
let currentPage = 1;           // Trang hiện tại đang xem

const currentUser = JSON.parse(localStorage.getItem('currentUser'));

$(document).ready(function() {
    
    // --- 1. SETUP NAVBAR & AUTH UI ---
    setupNavbar();

    function setupNavbar() {
        const authSection = $('#auth-section');
        if (currentUser) {
            authSection.html(`
                <div class="dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle"></i> ${currentUser.name}
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item text-danger" href="#" id="btn-logout" data-i18n="nav_logout">Đăng xuất</a></li>
                    </ul>
                </div>
            `);
            if (currentUser.role === 'admin') {
                $('#btn-add-tour').removeClass('d-none');
            }
        } else {
            authSection.html(`
                <a href="login.html" class="btn btn-outline-primary btn-sm rounded-pill px-3" data-i18n="nav_login">Đăng nhập</a>
            `);
        }
    }

    $('#nav-fav-link').click(function(e) {
        if (!currentUser) {
            e.preventDefault();
            alert("Vui lòng đăng nhập để xem danh sách yêu thích!");
            window.location.href = 'login.html';
        } else {
            window.location.href = 'favorites.html';
        }
    });

    $(document).on('click', '#btn-logout', function(e) {
        e.preventDefault();
        localStorage.removeItem('currentUser');
        window.location.href = 'index.html';
    });

    // --- 2. FETCH DATA ---
    fetchTours();

    // --- 3. FILTER & SEARCH ---
    $('#btn-search').click(filterData);
    $('#search-name, #search-duration, #filter-dest').keypress(e => { if(e.which == 13) filterData(); });
    $('#filter-price').change(filterData);

    function filterData() {
        const nameKey = $('#search-name').val().toLowerCase().trim();
        const durationKey = $('#search-duration').val().trim();
        const destKey = $('#filter-dest').val().toLowerCase().trim();
        const priceKey = $('#filter-price').val();

        // 1. Lọc từ danh sách gốc allTours
        const filtered = allTours.filter(t => {
            const matchName = t.title.toLowerCase().includes(nameKey);
            
            let matchDuration = true;
            if (durationKey) matchDuration = t.duration == durationKey;

            const matchDest = t.destination.toLowerCase().includes(destKey);

            let matchPrice = true;
            const price = parseInt(t.price);
            if (priceKey === 'under5') matchPrice = price < 5000000;
            else if (priceKey === '5to10') matchPrice = price >= 5000000 && price <= 10000000;
            else if (priceKey === 'over10') matchPrice = price > 10000000;

            return matchName && matchDuration && matchDest && matchPrice;
        });

        // 2. Cập nhật danh sách hiện tại VÀ Reset về trang 1
        currentFilteredTours = filtered;
        currentPage = 1;

        // 3. Gọi hàm vẽ trang (Thay vì renderTours trực tiếp)
        renderPage();
    }

    // --- 4. RENDER TOURS (Hàm vẽ danh sách tour) ---
    window.renderTours = function(tours) {
        const listContainer = $('#tour-list');
        listContainer.empty();

        if (tours.length === 0) {
            listContainer.html('<p class="text-center w-100 text-muted">Không tìm thấy tour phù hợp.</p>');
            return;
        }

        const favKey = currentUser ? `favorites_${currentUser.id}` : '';
        const favorites = currentUser ? (JSON.parse(localStorage.getItem(favKey)) || []) : [];
        
        // Link ảnh mặc định nếu ảnh gốc lỗi
        const defaultImg = 'https://placehold.co/400x250?text=No+Image';

        tours.forEach(tour => {
            let adminButtons = '';
            if (currentUser && currentUser.role === 'admin') {
                adminButtons = `
                    <div class="mt-3 d-flex gap-2">
                        <button class="btn btn-sm btn-outline-primary flex-grow-1 btn-edit" data-id="${tour.id}"><i class="fas fa-edit"></i> Sửa</button>
                        <button class="btn btn-sm btn-outline-danger flex-grow-1 btn-delete" data-id="${tour.id}"><i class="fas fa-trash"></i> Xóa</button>
                    </div>
                `;
            }

            const isFav = favorites.some(f => f.id == tour.id);
            const activeClass = isFav ? 'active' : '';

            const html = `
                <div class="col-md-4 col-sm-6 mb-4">
                    <div class="card h-100 shadow-sm border-0">
                        <div class="position-relative">
                            <img src="${tour.image || defaultImg}" 
                                 class="card-img-top" 
                                 alt="${tour.title}" 
                                 style="height: 200px; object-fit: cover;"
                                 onerror="this.onerror=null; this.src='${defaultImg}'">
                            <span class="btn-fav-card ${activeClass}" data-id="${tour.id}"><i class="fas fa-heart"></i></span>
                        </div>
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title text-truncate" title="${tour.title}">${tour.title}</h5>
                            <div class="tour-meta mb-2 small text-muted">
                                <i class="fas fa-map-marker-alt text-primary"></i> ${tour.destination} | 
                                <i class="fas fa-clock text-warning"></i> ${tour.duration} ngày
                            </div>
                            <p class="card-text text-truncate" style="max-height: 50px;">${tour.description || ''}</p>
                            <div class="mt-auto">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="price-tag fw-bold text-primary">${parseInt(tour.price).toLocaleString()} VNĐ</span>
                                    <button class="btn btn-primary btn-sm rounded-pill px-3">Chi tiết</button>
                                </div>
                                ${adminButtons}
                            </div>
                        </div>
                    </div>
                </div>
            `;
            listContainer.append(html);
        });
    };

    // --- 5. LOGIC YÊU THÍCH ---
    $(document).on('click', '.btn-fav-card', function() {
        if (!currentUser) {
            alert("Bạn cần đăng nhập để lưu tour yêu thích!");
            window.location.href = 'login.html';
            return;
        }
        const tourId = $(this).data('id');
        const btn = $(this);
        const favKey = `favorites_${currentUser.id}`;
        let favorites = JSON.parse(localStorage.getItem(favKey)) || [];

        const existsIndex = favorites.findIndex(f => f.id == tourId);
        if (existsIndex !== -1) {
            favorites.splice(existsIndex, 1);
            btn.removeClass('active');
        } else {
            const tourInfo = allTours.find(t => t.id == tourId);
            if (tourInfo) {
                favorites.push(tourInfo);
                btn.addClass('active');
            }
        }
        localStorage.setItem(favKey, JSON.stringify(favorites));
    });

    // --- 6. CRUD FUNCTIONS ---
    $('#form-tour').on('submit', function(e) {
        e.preventDefault();
        const id = $('#tour-id').val();
        const tourData = {
            title: $('#tour-title').val(),
            destination: $('#tour-destination').val(),
            price: parseInt($('#tour-price').val()),
            duration: parseInt($('#tour-duration').val()),
            image: $('#tour-image').val(),
            description: $('#tour-desc').val(),
            createdAt: new Date().toISOString()
        };

        // Sử dụng API_URL có sẵn của bạn
        const method = id ? 'PUT' : 'POST';
        const url = id ? `${API_URL}/tours/${id}` : `${API_URL}/tours`;

        $.ajax({
            url: url,
            method: method,
            data: tourData,
            success: function() {
                alert('Thành công!');
                $('#tourModal').modal('hide');
                $('#form-tour')[0].reset();
                $('#tour-id').val('');
                fetchTours();
            },
            error: () => alert('Lỗi khi xử lý dữ liệu!')
        });
    });

    $(document).on('click', '.btn-edit', function() {
        const id = $(this).data('id');
        const tour = allTours.find(t => t.id == id);
        if (tour) {
            $('#tour-id').val(tour.id);
            $('#tour-title').val(tour.title);
            $('#tour-destination').val(tour.destination);
            $('#tour-price').val(tour.price);
            $('#tour-duration').val(tour.duration);
            $('#tour-image').val(tour.image);
            $('#tour-desc').val(tour.description);
            $('#tourModalLabel').text("Cập Nhật Tour");
            $('#tourModal').modal('show');
        }
    });

    $('#btn-add-tour').click(function() {
        $('#form-tour')[0].reset();
        $('#tour-id').val('');
        $('#tourModalLabel').text("Thêm Tour Mới");
    });

    $(document).on('click', '.btn-delete', function() {
        const id = $(this).data('id');
        if (confirm('Bạn có chắc chắn muốn xóa tour này không?')) {
            $.ajax({
                url: API_URL + `/tours/${id}`,
                method: 'DELETE',
                success: function() {
                    alert('Đã xóa!');
                    fetchTours();
                },
                error: () => alert('Lỗi không thể xóa!')
            });
        }
    });

    // --- 7. PAGINATION LOGIC (Phần mới thêm) ---
    
    // Xử lý khi bấm vào nút phân trang (1, 2, Next, Prev)
    $(document).on('click', '.page-link', function(e) {
        e.preventDefault();
        const page = $(this).data('page');
        
        if (!page) return;

        const totalPages = Math.ceil(currentFilteredTours.length / ITEMS_PER_PAGE);

        if (page === 'prev') {
            if (currentPage > 1) currentPage--;
        } else if (page === 'next') {
            if (currentPage < totalPages) currentPage++;
        } else {
            currentPage = parseInt(page);
        }

        renderPage(); // Vẽ lại trang mới
        // Cuộn lên đầu danh sách tour
        $('html, body').animate({ scrollTop: $("#tour-list").offset().top - 100 }, 500);
    });

});

// --- HELPER FUNCTIONS ---

function fetchTours() {
    $.ajax({
        url: API_URL + '/tours',
        method: 'GET',
        success: function(data) {
            allTours = data;
            // Ban đầu chưa lọc gì thì danh sách hiển thị = toàn bộ dữ liệu
            currentFilteredTours = data;
            currentPage = 1;
            renderPage(); // Gọi hàm vẽ trang
        },
        error: function() { $('#tour-list').html('<p class="text-center text-danger">Lỗi kết nối API!</p>'); }
    });
}

// Hàm cắt dữ liệu và vẽ trang hiện tại
function renderPage() {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    const end = start + ITEMS_PER_PAGE;
    
    // Cắt lấy 6 tour (hoặc số lượng ITEMS_PER_PAGE)
    const toursToShow = currentFilteredTours.slice(start, end);

    // Vẽ tour
    renderTours(toursToShow);
    
    // Vẽ thanh phân trang
    renderPaginationUI();
}

// Hàm tạo HTML cho thanh phân trang
function renderPaginationUI() {
    const totalItems = currentFilteredTours.length;
    const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);
    
    // Nếu chỉ có 1 trang hoặc không có tour nào -> Ẩn thanh phân trang
    if (totalPages <= 1) {
        $('#pagination-container').remove();
        return;
    }

    // Nếu chưa có container phân trang thì tạo mới
    if ($('#pagination-container').length === 0) {
        $('#tour-list').after('<div id="pagination-container" class="d-flex justify-content-center mt-4"><ul class="pagination"></ul></div>');
    }

    const paginationUl = $('#pagination-container ul');
    paginationUl.empty();

    // Nút Previous
    const prevDisabled = currentPage === 1 ? 'disabled' : '';
    paginationUl.append(`
        <li class="page-item ${prevDisabled}">
            <a class="page-link" href="#" data-page="prev">&laquo; Trước</a>
        </li>
    `);

    // Các nút số trang
    for (let i = 1; i <= totalPages; i++) {
        const activeClass = i === currentPage ? 'active' : '';
        paginationUl.append(`
            <li class="page-item ${activeClass}">
                <a class="page-link" href="#" data-page="${i}">${i}</a>
            </li>
        `);
    }

    // Nút Next
    const nextDisabled = currentPage === totalPages ? 'disabled' : '';
    paginationUl.append(`
        <li class="page-item ${nextDisabled}">
            <a class="page-link" href="#" data-page="next">Sau &raquo;</a>
        </li>
    `);
}