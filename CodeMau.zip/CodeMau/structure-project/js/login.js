// js/login.js

$(document).ready(function() {
    
    // --- 0. HÀM TIỆN ÍCH UI ---
    function getTrans(key) {
        const lang = localStorage.getItem('lang') || 'vi';
        // Kiểm tra an toàn để tránh lỗi nếu chưa load file ngôn ngữ
        if (typeof translations !== 'undefined' && translations[lang] && translations[lang][key]) {
            return translations[lang][key];
        }
        return key; 
    }

    // Hàm hiển thị lỗi (Rung + Đỏ)
    function showError(input, messageKey) {
        const inputEl = $(input);
        const errorSpan = inputEl.next('.error-message');
        
        inputEl.addClass('input-error');
        inputEl.addClass('shake');
        errorSpan.text(getTrans(messageKey)); 
        errorSpan.show();

        setTimeout(() => { inputEl.removeClass('shake'); }, 500);
    }

    // Hàm xóa lỗi
    function clearError(input) {
        const inputEl = $(input);
        const errorSpan = inputEl.next('.error-message');
        inputEl.removeClass('input-error');
        errorSpan.hide();
    }

    $('input').on('input', function() { clearError(this); });


    // --- 1. SLIDE UI (Chuyển đổi qua lại Login/Register) ---
    const signUpBtn = document.getElementById('signUpBtn');
    const signInBtn = document.getElementById('signInBtn');
    const container = document.getElementById('container');

    signUpBtn.addEventListener('click', () => {
        container.classList.add("right-panel-active");
        $('#form-login')[0].reset();
        $('.error-message').hide(); 
        $('input').removeClass('input-error');
    });

    signInBtn.addEventListener('click', () => {
        container.classList.remove("right-panel-active");
        $('#form-signup')[0].reset();
        $('.error-message').hide();
        $('input').removeClass('input-error');
    });


    // --- 2. XỬ LÝ ĐĂNG KÝ (Logic chuẩn cho MockAPI 'users') ---
    $('#form-signup').on('submit', async function(e) {
        e.preventDefault(); 
        let isValid = true;

        const nameInput = $('#signup-name');
        const emailInput = $('#signup-email');
        const passInput = $('#signup-password');
        const nameVal = nameInput.val().trim();
        const emailVal = emailInput.val().trim();
        const passVal = passInput.val().trim();

        // Validate đầu vào
        if (nameVal === '') { showError(nameInput, 'err_required'); isValid = false; }
        if (emailVal === '') { showError(emailInput, 'err_required'); isValid = false; }
        else if (!validateEmail(emailVal)) { showError(emailInput, 'err_email_invalid'); isValid = false; }
        if (passVal === '') { showError(passInput, 'err_required'); isValid = false; }
        else if (passVal.length < 6) { showError(passInput, 'err_pass_short'); isValid = false; }

        if (!isValid) return;

        try {
            // Bước 1: Kiểm tra email đã tồn tại chưa
            // QUAN TRỌNG: Dùng /users (số nhiều) khớp với ảnh của bạn
            let emailExists = false;
            
            // Log URL ra console để bạn kiểm tra nếu lỗi
            console.log("Checking email at:", `${API_URL}/users?email=${encodeURIComponent(emailVal)}`);

            try {
                const checkData = await $.ajax({
                    url: `${API_URL}/users?email=${encodeURIComponent(emailVal)}`, 
                    method: 'GET'
                });
                
                if (checkData.length > 0) emailExists = true;

            } catch (checkError) {
                // MockAPI đôi khi trả 404 nếu tìm không thấy -> Coi là chưa tồn tại (Hợp lệ)
                if (checkError.status === 404) {
                    emailExists = false;
                } else {
                    throw checkError; // Lỗi khác thì ném ra ngoài
                }
            }

            if (emailExists) {
                showError(emailInput, 'err_email_exists');
            } else {
                // Bước 2: Tạo tài khoản mới
                const newUser = {
                    name: nameVal,
                    email: emailVal,
                    password: passVal,
                    createdAt: new Date().toISOString()
                };

                // Gửi POST với định dạng JSON chuẩn
                await $.ajax({
                    url: `${API_URL}/users`, // Dùng /users (số nhiều)
                    method: 'POST',
                    contentType: 'application/json', // Bắt buộc cho MockAPI
                    data: JSON.stringify(newUser)    // Bắt buộc chuyển object sang string
                });

                alert(getTrans('success_signup'));
                container.classList.remove("right-panel-active"); // Về form login
                $('#form-signup')[0].reset();
            }

        } catch (error) {
            console.error("Lỗi đăng ký chi tiết:", error);
            alert(getTrans('err_network') + " (Xem console để biết chi tiết)");
        }
    });


    // --- 3. XỬ LÝ ĐĂNG NHẬP (Logic chuẩn cho MockAPI 'users') ---
    $('#form-login').on('submit', async function(e) {
        e.preventDefault();
        let isValid = true;
        const emailInput = $('#login-email');
        const passInput = $('#login-password');
        const emailVal = emailInput.val().trim();
        const passVal = passInput.val().trim();

        if (emailVal === '') { showError(emailInput, 'err_required'); isValid = false; }
        if (passVal === '') { showError(passInput, 'err_required'); isValid = false; }
        if (!isValid) return;

        try {
            // Gọi API tìm user (Dùng /users số nhiều)
            const data = await $.ajax({
                url: `${API_URL}/users?email=${encodeURIComponent(emailVal)}`, 
                method: 'GET'
            });

            if (data.length === 0) {
                showError(emailInput, 'err_email_not_found');
                passInput.val('');
            } else {
                const user = data[0];
                // So sánh password (MockAPI lưu password dạng text thường)
                if (user.password === passVal) {
                    // --- ĐĂNG NHẬP THÀNH CÔNG ---
                    let role = 'user';
                    if (user.email === 'nam@gmail.com') role = 'admin'; // Ví dụ set admin

                    const sessionData = {
                        id: user.id,
                        name: user.name,
                        email: user.email,
                        role: role
                    };
                    localStorage.setItem('currentUser', JSON.stringify(sessionData));
                    
                    alert(`Xin chào ${user.name}!`);
                    window.location.href = 'index.html';
                } else {
                    // Sai password
                    showError(passInput, 'err_password_wrong');
                    passInput.val('');
                    passInput.focus();
                }
            }
        } catch (error) {
            console.error("Lỗi login:", error);
            
            // Xử lý trường hợp MockAPI trả 404 khi không tìm thấy email
            if (error.status === 404) {
                showError(emailInput, 'err_email_not_found');
            } else {
                alert(getTrans('err_network'));
            }
        }
    });

});