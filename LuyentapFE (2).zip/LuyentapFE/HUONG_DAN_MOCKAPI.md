# Hướng Dẫn Thiết Lập MockAPI

## Bước 1: Tạo Tài Khoản MockAPI

1. Truy cập: https://mockapi.io/
2. Đăng ký tài khoản miễn phí (có thể dùng Google/GitHub)

## Bước 2: Tạo Project Mới

1. Sau khi đăng nhập, click "New Project"
2. Đặt tên project: "QuanLyTour" (hoặc tên bạn muốn)

## Bước 3: Tạo Resource "users"

1. Click "Add Resource"
2. Đặt tên resource: `users`
3. Thêm các fields:
   - `name` (String)
   - `email` (String)
   - `password` (String)
   - `createdAt` (String)
4. Click "Create"

## Bước 4: Tạo Resource "tours"

1. Click "Add Resource"
2. Đặt tên resource: `tours`
3. Thêm các fields:
   - `title` (String)
   - `destination` (String)
   - `price` (Number)
   - `duration` (Number)
   - `description` (String)
   - `createdAt` (String)
4. Click "Create"

## Bước 5: Lấy API URL

1. Vào trang project của bạn
2. Copy Base URL (ví dụ: `https://65f1b0b3034bdbecc7630e6c.mockapi.io`)
3. Mở file `js/main.js`
4. Tìm dòng:
   ```javascript
   const MOCKAPI_BASE_URL = 'https://65f1b0b3034bdbecc7630e6c.mockapi.io';
   ```
5. Thay thế bằng Base URL của bạn

## Bước 6: Kiểm Tra

1. Mở ứng dụng trong trình duyệt
2. Thử đăng ký tài khoản mới
3. Kiểm tra trên MockAPI xem có dữ liệu user mới không

## Lưu Ý

- MockAPI miễn phí có giới hạn 100 requests/giờ
- Dữ liệu sẽ được lưu trên server MockAPI
- Nếu muốn reset dữ liệu, có thể xóa và tạo lại resources

## URL Mẫu

Sau khi tạo xong, bạn sẽ có 2 endpoints:
- Users: `https://[YOUR-ID].mockapi.io/users`
- Tours: `https://[YOUR-ID].mockapi.io/tours`

Thay `[YOUR-ID]` bằng ID project của bạn trên MockAPI.

