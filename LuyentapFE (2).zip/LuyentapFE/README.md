# Ứng Dụng Quản Lý Tour Du Lịch

Ứng dụng web quản lý tour du lịch được xây dựng bằng HTML, CSS, JavaScript, jQuery và Bootstrap.

## 🚀 Tính Năng

### Chức Năng Bắt Buộc

1. **Quản Lý Người Dùng**
   - Đăng nhập với email và mật khẩu
   - Đăng ký tài khoản mới (kiểm tra trùng email)
   - Đăng xuất

2. **Quản Lý Tour Du Lịch**
   - Hiển thị danh sách tour với giao diện đẹp
   - Thêm tour mới (chỉ dành cho người dùng đã đăng nhập)
   - Sửa tour (chỉ dành cho người dùng đã đăng nhập)
   - Xóa tour (chỉ dành cho người dùng đã đăng nhập)
   - Lọc tour theo địa điểm
   - Lọc tour theo giá (dưới 1 triệu, 1-3 triệu, 3-5 triệu, trên 5 triệu)
   - Tìm kiếm tour theo tên hoặc thời lượng (duration)

3. **Danh Sách Tour Yêu Thích**
   - Thêm/xóa tour vào danh sách yêu thích
   - Xem danh sách tour yêu thích
   - Thêm/sửa ghi chú cho tour yêu thích
   - Dữ liệu lưu trong LocalStorage

### Chức Năng Nâng Cao

- **Animation**: Các hiệu ứng chuyển động mượt mà, fade in, slide in
- **Performance**: Tối ưu hóa hiệu suất với lazy loading và caching
- **Responsive Design**: Giao diện đẹp trên mọi thiết bị

## 📋 Yêu Cầu Hệ Thống

- Trình duyệt web hiện đại (Chrome, Firefox, Edge, Safari)
- Kết nối Internet để truy cập MockAPI

## 🛠️ Cài Đặt

1. Clone hoặc tải project về máy
2. Mở file `index.html` bằng trình duyệt web
3. Hoặc sử dụng local server (khuyến nghị):
   ```bash
   # Sử dụng Python
   python -m http.server 8000
   
   # Sử dụng Node.js (http-server)
   npx http-server
   ```

## 📡 Cấu Hình MockAPI

Ứng dụng sử dụng MockAPI với 2 resources:

### 1. Users Resource
- **URL**: `https://65f1b0b3034bdbecc7630e6c.mockapi.io/users`
- **Schema**:
  ```json
  {
    "id": "string",
    "name": "string",
    "email": "string",
    "password": "string",
    "createdAt": "string (ISO date)"
  }
  ```

### 2. Tours Resource
- **URL**: `https://65f1b0b3034bdbecc7630e6c.mockapi.io/tours`
- **Schema**:
  ```json
  {
    "id": "string",
    "title": "string",
    "destination": "string",
    "price": "number",
    "duration": "number",
    "description": "string",
    "createdAt": "string (ISO date)"
  }
  ```

**Lưu ý**: Bạn cần tạo các resources này trên MockAPI trước khi sử dụng ứng dụng.

## 🎨 Cấu Trúc Thư Mục

```
LuyentapFE/
│
├── index.html          # File HTML chính
├── css/
│   └── style.css       # File CSS với animation
├── js/
│   └── main.js         # File JavaScript chính
└── README.md           # File hướng dẫn
```

## 💻 Cách Sử Dụng

### Đăng Ký Tài Khoản
1. Click vào nút "Đăng Ký" trên thanh navigation
2. Điền đầy đủ thông tin: Tên, Email, Mật khẩu
3. Click "Đăng Ký" để tạo tài khoản

### Đăng Nhập
1. Click vào nút "Đăng Nhập" trên thanh navigation
2. Nhập email và mật khẩu đã đăng ký
3. Click "Đăng Nhập"

### Quản Lý Tour
- **Xem danh sách tour**: Click "Danh Sách Tour" trên menu
- **Thêm tour**: Click "Thêm Tour Mới" (chỉ khi đã đăng nhập)
- **Sửa tour**: Click nút "Sửa" trên card tour (chỉ khi đã đăng nhập)
- **Xóa tour**: Click nút "Xóa" trên card tour (chỉ khi đã đăng nhập)
- **Tìm kiếm**: Nhập từ khóa vào ô tìm kiếm
- **Lọc**: Chọn địa điểm hoặc giá từ dropdown

### Tour Yêu Thích
- **Thêm vào yêu thích**: Click nút "Yêu Thích" trên card tour
- **Xem danh sách**: Click "Tour Yêu Thích" trên menu
- **Thêm ghi chú**: Click "Thêm Ghi Chú" trên tour yêu thích
- **Xóa khỏi yêu thích**: Click "Xóa" trên tour yêu thích

## 🎯 Công Nghệ Sử Dụng

- **HTML5**: Cấu trúc trang web
- **CSS3**: Styling và animation
- **JavaScript (ES6+)**: Logic xử lý
- **jQuery 3.7.0**: DOM manipulation và AJAX
- **Bootstrap 5.3.0**: Framework UI responsive
- **Bootstrap Icons**: Icon set
- **MockAPI**: Fake REST API
- **LocalStorage**: Lưu trữ tour yêu thích

## 📝 Ghi Chú

- Tất cả tên biến và hàm được đặt bằng tiếng Việt theo phong cách sinh viên
- Dữ liệu tour yêu thích được lưu trong LocalStorage của trình duyệt
- Thông tin đăng nhập được lưu trong LocalStorage để tự động đăng nhập lại
- Ứng dụng hỗ trợ responsive trên mobile, tablet và desktop

## 🔒 Bảo Mật

- Mật khẩu được lưu dạng plain text trong MockAPI (chỉ dùng cho mục đích học tập)
- Trong môi trường production, cần mã hóa mật khẩu và sử dụng JWT token

## 📄 License

Dự án này được tạo cho mục đích học tập.

