// ============================================
// CẤU HÌNH MOCKAPI
// ============================================
const MOCKAPI_BASE_URL = 'https://66494e064032b1331beda92d.mockapi.io/api/v2';
const API_TOURS = `${MOCKAPI_BASE_URL}/sanpham`;

// ============================================
// BIẾN TOÀN CỤC
// ============================================
let danhSachTour = [];
let danhSachTourLoc = [];

// ============================================
// KHỞI TẠO ỨNG DỤNG
// ============================================
$(document).ready(function() {
    kiemTraDangNhap();
    khoiTaoSuKien();
    taiDanhSachTour();
});

// ============================================
// KIỂM TRA ĐĂNG NHẬP
// ============================================
function kiemTraDangNhap() {
    const thongTinDangNhap = localStorage.getItem('thongTinDangNhap');
    if (!thongTinDangNhap) {
        // Chưa đăng nhập, chuyển về trang login
        window.location.href = 'login.html';
        return;
    }
    
    const nguoiDung = JSON.parse(thongTinDangNhap);
    $('#tenAdmin').text(nguoiDung.name || 'Admin');
}

// ============================================
// KHỞI TẠO SỰ KIỆN
// ============================================
function khoiTaoSuKien() {
    // Đăng xuất
    $('#btnDangXuat').click(function() {
        if (confirm('Bạn có chắc chắn muốn đăng xuất?')) {
            localStorage.removeItem('thongTinDangNhap');
            window.location.href = 'login.html';
        }
    });
    
    // Thêm tour mới
    $('#btnThemTourMoi').click(function() {
        moModalThemTour();
    });
    
    // Lưu tour
    $('#btnLuuTour').click(function() {
        luuTour();
    });
    
    // Tìm kiếm và lọc
    $('#timKiemTour').on('input', function() {
        locVaTimKiemTour();
    });
    
    $('#locDiaDiem').change(function() {
        locVaTimKiemTour();
    });
    
    $('#locGia').change(function() {
        locVaTimKiemTour();
    });
    
    $('#btnXoaLoc').click(function() {
        $('#timKiemTour').val('');
        $('#locDiaDiem').val('');
        $('#locGia').val('');
        locVaTimKiemTour();
    });
}

// ============================================
// TẢI DANH SÁCH TOUR
// ============================================
async function taiDanhSachTour() {
    hienThiLoading(true);
    
    try {
        const response = await $.ajax({
            url: API_TOURS,
            method: 'GET'
        });
        
        danhSachTour = response;
        danhSachTourLoc = danhSachTour;
        hienThiDanhSachTourCards(danhSachTourLoc);
        capNhatSelectDiaDiem();
        capNhatThongKe();
    } catch (error) {
        console.error('Lỗi tải danh sách tour:', error);
        hienThiThongBao('Không thể tải danh sách tour!', 'danger');
    } finally {
        hienThiLoading(false);
    }
}

// ============================================
// HIỂN THỊ DANH SÁCH TOUR CARDS
// ============================================
function hienThiDanhSachTourCards(tours) {
    const container = $('#danhSachTourCards');
    const thongBao = $('#thongBaoKhongCoTour');
    
    container.empty();
    
    if (tours.length === 0) {
        container.hide();
        thongBao.show();
        return;
    }
    
    thongBao.hide();
    container.show();
    
    tours.forEach((tour, index) => {
        const card = taoCardTour(tour, index);
        container.append(card);
    });
}

// ============================================
// TẠO CARD TOUR
// ============================================
function taoCardTour(tour, index) {
    const giaFormatted = formatGia(tour.price);
    const ngayTao = new Date(tour.createdAt).toLocaleDateString('vi-VN');
    const imageHtml = tour.image ? 
        `<div class="card-img-top-container">
            <img src="${tour.image}" class="card-img-top" alt="${tour.title}" onerror="this.src='https://via.placeholder.com/400x250?text=Tour+Image'">
        </div>` : 
        `<div class="card-img-top-container">
            <div class="card-img-placeholder">
                <i class="bi bi-image"></i>
                <p>Không có ảnh</p>
            </div>
        </div>`;
    
    return $(`
        <div class="col-md-6 col-lg-4 tour-card-admin" style="animation-delay: ${index * 0.1}s">
            <div class="card card-admin">
                ${imageHtml}
                <div class="card-body card-body-admin">
                    <h5 class="card-title card-title-admin">${tour.title}</h5>
                    <p class="card-text card-text-admin">
                        <i class="bi bi-geo-alt-fill text-primary"></i> 
                        <strong>${tour.destination}</strong>
                    </p>
                    <p class="card-text card-text-admin">${tour.description}</p>
                    <div class="gia-tour-admin">${giaFormatted}</div>
                    <div>
                        <span class="thoi-luong-admin">
                            <i class="bi bi-clock"></i> ${tour.duration} ngày
                        </span>
                    </div>
                    <div class="mt-2">
                        <small class="text-muted">
                            <i class="bi bi-calendar"></i> ${ngayTao}
                        </small>
                    </div>
                    <div class="action-buttons-admin">
                        <button class="btn btn-sm btn-info" onclick="moModalSuaTour('${tour.id}')">
                            <i class="bi bi-pencil"></i> Sửa
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="xoaTour('${tour.id}')">
                            <i class="bi bi-trash"></i> Xóa
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `);
}

// ============================================
// CẬP NHẬT SELECT ĐỊA ĐIỂM
// ============================================
function capNhatSelectDiaDiem() {
    const select = $('#locDiaDiem');
    const diaDiemHienCo = [...new Set(danhSachTour.map(t => t.destination))];
    
    select.find('option:not(:first)').remove();
    
    diaDiemHienCo.forEach(diaDiem => {
        select.append(`<option value="${diaDiem}">${diaDiem}</option>`);
    });
}

// ============================================
// LỌC VÀ TÌM KIẾM TOUR
// ============================================
function locVaTimKiemTour() {
    const tuKhoa = $('#timKiemTour').val().toLowerCase();
    const diaDiem = $('#locDiaDiem').val();
    const gia = $('#locGia').val();
    
    danhSachTourLoc = danhSachTour.filter(tour => {
        // Tìm kiếm theo tên hoặc thời lượng
        const timKiem = !tuKhoa || 
            tour.title.toLowerCase().includes(tuKhoa) || 
            tour.duration.toString().includes(tuKhoa);
        
        // Lọc theo địa điểm
        const locDiaDiem = !diaDiem || tour.destination === diaDiem;
        
        // Lọc theo giá
        let locGia = true;
        if (gia) {
            const [min, max] = gia.split('-').map(Number);
            locGia = tour.price >= min && tour.price <= max;
        }
        
        return timKiem && locDiaDiem && locGia;
    });
    
    hienThiDanhSachTourCards(danhSachTourLoc);
    capNhatThongKe();
}

// ============================================
// CẬP NHẬT THỐNG KÊ
// ============================================
function capNhatThongKe() {
    // Tổng số tour
    $('#tongSoTour').text(danhSachTourLoc.length);
    
    // Tổng số địa điểm
    const diaDiem = [...new Set(danhSachTourLoc.map(t => t.destination))];
    $('#tongDiaDiem').text(diaDiem.length);
    
    // Giá trung bình
    if (danhSachTourLoc.length > 0) {
        const tongGia = danhSachTourLoc.reduce((sum, tour) => sum + (tour.price || 0), 0);
        const giaTrungBinh = Math.round(tongGia / danhSachTourLoc.length);
        $('#giaTrungBinh').text(formatGia(giaTrungBinh));
    } else {
        $('#giaTrungBinh').text('0 ₫');
    }
}

// ============================================
// MỞ MODAL THÊM TOUR
// ============================================
function moModalThemTour() {
    $('#tieuDeModalTour').html('<i class="bi bi-plus-circle"></i> Thêm Tour Mới');
    $('#formTour')[0].reset();
    $('#tourId').val('');
    $('#previewImageContainer').hide();
    $('#currentImagePreview').hide();
    $('#fileAnhTour').val('');
    $('#modalTour').modal('show');
}

// ============================================
// MỞ MODAL SỬA TOUR
// ============================================
function moModalSuaTour(tourId) {
    const tour = danhSachTour.find(t => t.id === tourId);
    if (!tour) {
        hienThiThongBao('Không tìm thấy tour!', 'danger');
        return;
    }
    
    $('#tieuDeModalTour').html('<i class="bi bi-pencil"></i> Sửa Tour');
    $('#tourId').val(tour.id);
    $('#tenTour').val(tour.title);
    $('#diaDiemTour').val(tour.destination);
    $('#giaTour').val(tour.price);
    $('#thoiLuongTour').val(tour.duration);
    $('#moTaTour').val(tour.description);
    $('#anhTour').val(tour.image || '');
    $('#fileAnhTour').val('');
    $('#previewImageContainer').hide();
    
    // Hiển thị ảnh hiện tại nếu có
    if (tour.image) {
        $('#currentImage').attr('src', tour.image);
        $('#currentImagePreview').show();
    } else {
        $('#currentImagePreview').hide();
    }
    
    $('#modalTour').modal('show');
}

// ============================================
// LƯU TOUR
// ============================================
async function luuTour() {
    const tourId = $('#tourId').val();
    
    // Xử lý ảnh
    let imageUrl = $('#anhTour').val().trim();
    const fileInput = document.getElementById('fileAnhTour');
    
    // Nếu có file ảnh được chọn, convert sang base64 (ưu tiên file hơn URL)
    if (fileInput.files && fileInput.files[0]) {
        try {
            imageUrl = await convertImageToBase64(fileInput.files[0]);
        } catch (error) {
            console.error('Lỗi convert ảnh:', error);
            hienThiThongBao('Có lỗi khi xử lý ảnh!', 'warning');
            return;
        }
    }
    
    const tourData = {
        title: $('#tenTour').val().trim(),
        destination: $('#diaDiemTour').val().trim(),
        price: parseInt($('#giaTour').val()),
        duration: parseInt($('#thoiLuongTour').val()),
        description: $('#moTaTour').val().trim(),
        image: imageUrl || ''
    };
    
    // Validate
    if (!tourData.title || !tourData.destination || !tourData.price || !tourData.duration || !tourData.description) {
        hienThiThongBao('Vui lòng nhập đầy đủ thông tin!', 'warning');
        return;
    }
    
    if (tourData.price < 0) {
        hienThiThongBao('Giá tour phải lớn hơn hoặc bằng 0!', 'warning');
        return;
    }
    
    if (tourData.duration < 1) {
        hienThiThongBao('Thời lượng tour phải lớn hơn 0!', 'warning');
        return;
    }
    
    hienThiLoading(true);
    
    try {
        if (tourId) {
            // Sửa tour
            await $.ajax({
                url: `${API_TOURS}/${tourId}`,
                method: 'PUT',
                contentType: 'application/json',
                data: JSON.stringify(tourData)
            });
            hienThiThongBao('Sửa tour thành công!', 'success');
        } else {
            // Thêm tour mới
            tourData.createdAt = new Date().toISOString();
            await $.ajax({
                url: API_TOURS,
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(tourData)
            });
            hienThiThongBao('Thêm tour thành công!', 'success');
        }
        
        $('#modalTour').modal('hide');
        await taiDanhSachTour();
    } catch (error) {
        console.error('Lỗi lưu tour:', error);
        hienThiThongBao('Có lỗi xảy ra khi lưu tour!', 'danger');
    } finally {
        hienThiLoading(false);
    }
}

// ============================================
// XÓA TOUR
// ============================================
async function xoaTour(tourId) {
    if (!confirm('Bạn có chắc chắn muốn xóa tour này? Hành động này không thể hoàn tác!')) {
        return;
    }
    
    hienThiLoading(true);
    
    try {
        await $.ajax({
            url: `${API_TOURS}/${tourId}`,
            method: 'DELETE'
        });
        
        hienThiThongBao('Xóa tour thành công!', 'success');
        await taiDanhSachTour();
    } catch (error) {
        console.error('Lỗi xóa tour:', error);
        hienThiThongBao('Có lỗi xảy ra khi xóa tour!', 'danger');
    } finally {
        hienThiLoading(false);
    }
}

// ============================================
// ĐỊNH DẠNG GIÁ
// ============================================
function formatGia(gia) {
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(gia);
}

// ============================================
// HIỂN THỊ LOADING
// ============================================
function hienThiLoading(show) {
    if (show) {
        $('#loadingSpinner').fadeIn();
    } else {
        $('#loadingSpinner').fadeOut();
    }
}

// ============================================
// HIỂN THỊ THÔNG BÁO
// ============================================
function hienThiThongBao(message, type = 'info') {
    const alertClass = {
        'success': 'alert-success',
        'danger': 'alert-danger',
        'warning': 'alert-warning',
        'info': 'alert-info'
    }[type] || 'alert-info';
    
    const icon = {
        'success': 'bi-check-circle-fill',
        'danger': 'bi-exclamation-triangle-fill',
        'warning': 'bi-exclamation-circle-fill',
        'info': 'bi-info-circle-fill'
    }[type] || 'bi-info-circle-fill';
    
    const toast = $(`
        <div class="alert ${alertClass} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3" 
             style="z-index: 10000; min-width: 300px; box-shadow: 0 5px 15px rgba(0,0,0,0.3); border-radius: 20px;" role="alert">
            <i class="bi ${icon}"></i> ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `);
    
    $('body').append(toast);
    
    setTimeout(() => {
        toast.fadeOut(() => toast.remove());
    }, 3000);
}

