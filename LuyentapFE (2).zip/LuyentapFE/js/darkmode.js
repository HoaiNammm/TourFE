// ============================================
// DARK MODE / LIGHT MODE TOGGLE
// ============================================

// Lấy theme từ localStorage hoặc mặc định là light
const currentTheme = localStorage.getItem('theme') || 'light';
document.documentElement.setAttribute('data-theme', currentTheme);

// Cập nhật UI khi load trang
function updateThemeUI(theme) {
    const modeLabel = document.getElementById('modeLabel');
    const themeIcon = document.getElementById('themeIcon');
    
    if (modeLabel) {
        // Lấy ngôn ngữ hiện tại
        const lang = localStorage.getItem('language') || 'vi';
        const translations = {
            en: { light: 'Light', dark: 'Dark' },
            vi: { light: 'Sáng', dark: 'Tối' }
        };
        modeLabel.textContent = translations[lang] ? translations[lang][theme] : (theme === 'dark' ? 'Tối' : 'Sáng');
    }
    
    if (themeIcon) {
        themeIcon.className = theme === 'dark' ? 'bi bi-moon-stars-fill' : 'bi bi-sun-fill';
    }
}

// Hàm chuyển đổi theme
function toggleTheme() {
    const root = document.documentElement;
    const currentTheme = root.getAttribute('data-theme') || 'light';
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    // Áp dụng theme mới
    root.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    
    // Cập nhật UI
    updateThemeUI(newTheme);
    
    // Thêm animation
    document.body.style.transition = 'background 0.3s ease, color 0.3s ease';
}

// Khởi tạo khi DOM ready
$(document).ready(function() {
    // Cập nhật UI ban đầu
    const initialTheme = document.documentElement.getAttribute('data-theme') || 'light';
    updateThemeUI(initialTheme);
    
    // Lắng nghe thay đổi ngôn ngữ để cập nhật label
    $(document).on('languageChanged', function() {
        const theme = document.documentElement.getAttribute('data-theme') || 'light';
        updateThemeUI(theme);
    });
});
