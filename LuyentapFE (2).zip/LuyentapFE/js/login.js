// ============================================
// CẤU HÌNH MOCKAPI
// ============================================
const MOCKAPI_BASE_URL = 'https://66494e064032b1331beda92d.mockapi.io/api/v2';
const API_USERS = `${MOCKAPI_BASE_URL}/user`;

// ============================================
// KHỞI TẠO SỰ KIỆN CHUYỂN ĐỔI FORM
// ============================================
const signUp = document.getElementById('signup');
const login = document.getElementById('login');
const container = document.getElementById('container');

signUp.addEventListener('click', () => {
    container.classList.add('right-panel-active');
    // Xóa thông báo lỗi khi chuyển form
    $('#thongBaoLoiDangKy').hide().text('');
    $('#thongBaoThanhCongDangKy').hide().text('');
});

login.addEventListener('click', () => {
    container.classList.remove('right-panel-active');
    // Xóa thông báo lỗi khi chuyển form
    $('#thongBaoLoiDangNhap').hide().text('');
});

// ============================================
// XỬ LÝ ĐĂNG NHẬP
// ============================================
$(document).ready(function() {
    // Xử lý form đăng nhập
    $('#formDangNhap').submit(function(e) {
        e.preventDefault();
        xuLyDangNhap();
    });

    $('#btnXacNhanDangNhap').click(function(e) {
        e.preventDefault();
        xuLyDangNhap();
    });

    // Xử lý form đăng ký
    $('#formDangKy').submit(function(e) {
        e.preventDefault();
        xuLyDangKy();
    });

    $('#btnXacNhanDangKy').click(function(e) {
        e.preventDefault();
        xuLyDangKy();
    });
});

async function xuLyDangNhap() {
    const email = $('#emailDangNhap').val().trim();
    const matKhau = $('#matKhauDangNhap').val().trim();
    
    // Ẩn thông báo lỗi cũ
    $('#thongBaoLoiDangNhap').hide();
    
    // Kiểm tra dữ liệu đầu vào
    if (!email || !matKhau) {
        hienThiThongBaoLoi('thongBaoLoiDangNhap', 'Vui lòng nhập đầy đủ thông tin!');
        return;
    }

    // Kiểm tra định dạng email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        hienThiThongBaoLoi('thongBaoLoiDangNhap', 'Email không hợp lệ!');
        return;
    }
    
    hienThiLoading(true);
    
    try {
        const response = await $.ajax({
            url: API_USERS,
            method: 'GET'
        });
        
        const nguoiDung = response.find(u => u.email === email && u.password === matKhau);
        
        if (nguoiDung) {
            // Lưu thông tin đăng nhập vào localStorage
            localStorage.setItem('thongTinDangNhap', JSON.stringify(nguoiDung));
            
            // Hiển thị thông báo thành công
            hienThiThongBaoThanhCong('Đăng nhập thành công! Đang chuyển hướng...');
            
            // Chuyển về trang chủ sau 1 giây
            setTimeout(() => {
                window.location.href = 'index.html';
            }, 1000);
        } else {
            hienThiThongBaoLoi('thongBaoLoiDangNhap', 'Email hoặc mật khẩu không đúng!');
        }
    } catch (error) {
        console.error('Lỗi đăng nhập:', error);
        hienThiThongBaoLoi('thongBaoLoiDangNhap', 'Có lỗi xảy ra khi đăng nhập! Vui lòng thử lại sau.');
    } finally {
        hienThiLoading(false);
    }
}

// ============================================
// XỬ LÝ ĐĂNG KÝ
// ============================================
async function xuLyDangKy() {
    const ten = $('#tenDangKy').val().trim();
    const email = $('#emailDangKy').val().trim();
    const matKhau = $('#matKhauDangKy').val().trim();
    
    // Ẩn thông báo cũ
    $('#thongBaoLoiDangKy').hide();
    $('#thongBaoThanhCongDangKy').hide();
    
    // Kiểm tra dữ liệu đầu vào
    if (!ten || !email || !matKhau) {
        hienThiThongBaoLoi('thongBaoLoiDangKy', 'Vui lòng nhập đầy đủ thông tin!');
        return;
    }

    // Kiểm tra định dạng email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        hienThiThongBaoLoi('thongBaoLoiDangKy', 'Email không hợp lệ!');
        return;
    }

    // Kiểm tra độ dài mật khẩu
    if (matKhau.length < 6) {
        hienThiThongBaoLoi('thongBaoLoiDangKy', 'Mật khẩu phải có ít nhất 6 ký tự!');
        return;
    }
    
    hienThiLoading(true);
    
    try {
        // Kiểm tra email trùng lặp
        const response = await $.ajax({
            url: API_USERS,
            method: 'GET'
        });
        
        const emailTrung = response.find(u => u.email === email);
        
        if (emailTrung) {
            hienThiThongBaoLoi('thongBaoLoiDangKy', 'Email này đã được sử dụng! Vui lòng chọn email khác.');
            hienThiLoading(false);
            return;
        }
        
        // Tạo tài khoản mới
        const taiKhoanMoi = {
            name: ten,
            email: email,
            password: matKhau,
            createdAt: new Date().toISOString()
        };
        
        const nguoiDungMoi = await $.ajax({
            url: API_USERS,
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(taiKhoanMoi)
        });
        
        // Lưu thông tin đăng nhập vào localStorage
        localStorage.setItem('thongTinDangNhap', JSON.stringify(nguoiDungMoi));
        
        // Hiển thị thông báo thành công
        hienThiThongBaoThanhCong('Đăng ký thành công! Đang chuyển hướng...');
        
        // Chuyển về trang chủ sau 1.5 giây
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 1500);
        
    } catch (error) {
        console.error('Lỗi đăng ký:', error);
        hienThiThongBaoLoi('thongBaoLoiDangKy', 'Có lỗi xảy ra khi đăng ký! Vui lòng thử lại sau.');
    } finally {
        hienThiLoading(false);
    }
}

// ============================================
// HIỂN THỊ LOADING
// ============================================
function hienThiLoading(show) {
    if (show) {
        $('#loadingSpinner').fadeIn();
    } else {
        $('#loadingSpinner').fadeOut();
    }
}

// ============================================
// HIỂN THỊ THÔNG BÁO LỖI
// ============================================
function hienThiThongBaoLoi(id, message) {
    const element = $(`#${id}`);
    element.text(message).fadeIn();
    
    // Tự động ẩn sau 5 giây
    setTimeout(() => {
        element.fadeOut();
    }, 5000);
}

// ============================================
// HIỂN THỊ THÔNG BÁO THÀNH CÔNG
// ============================================
function hienThiThongBaoThanhCong(message) {
    const element = $('#thongBaoThanhCongDangKy');
    element.text(message).fadeIn();
    
    // Không tự động ẩn vì sẽ chuyển trang
}

// ============================================
// KIỂM TRA ĐĂNG NHẬP KHI LOAD TRANG
// ============================================
$(document).ready(function() {
    // Nếu đã đăng nhập, chuyển về trang chủ
    const thongTinDangNhap = localStorage.getItem('thongTinDangNhap');
    if (thongTinDangNhap) {
        window.location.href = 'index.html';
    }
});
