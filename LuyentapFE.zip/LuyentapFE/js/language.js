// ============================================
// ĐA NGÔN NGỮ (i18n)
// ============================================
const translations = {
    en: {
        // Navigation
        'nav-home': 'Home',
        'nav-tours': 'Tour List',
        'nav-favorites': 'Favorites',
        'nav-login': 'Login / Register',
        
        'nav-admin': 'Admin Panel',
        'nav-logout': 'Logout',
        'nav-user': 'User',
        
        // Hero Section
        'title': 'Explore The World With Us',
        'description': 'Find and book the best tours at affordable prices',
        'btn-view-tours': 'View Tours Now',
        
        // Tour List
        'tour-list-title': 'Tour List',
        'search-placeholder': 'Search by tour name or duration...',
        'filter-location': 'Filter By Location',
        'filter-price': 'Filter By Price',
        'filter-all-location': 'All Locations',
        'filter-all-price': 'All Prices',
        'filter-price-under': 'Under 1 million',
        'filter-price-1-3': '1 - 3 million',
        'filter-price-3-5': '3 - 5 million',
        'filter-price-over': 'Over 5 million',
        'btn-clear-filter': 'Clear Filter',
        
        // Favorites
        'favorites-title': 'My Favorite Tours',
        'favorites-empty': "You don't have any favorite tours yet. Add tours to your favorites list!",
        'btn-favorite': 'Favorite',
        'btn-favorited': 'Favorited',
        
        // Tour Card
        'tour-duration': 'days',
        'btn-add-note': 'Add Note',
        'btn-edit-note': 'Edit Note',
        'btn-delete': 'Delete',
        
        // Theme
        'theme-light': 'Light',
        'theme-dark': 'Dark',
        
        // Common
        'loading': 'Loading...',
        'no-tours': 'No tours available!',
    },
    vi: {
        // Navigation
        'nav-home': 'Trang Chủ',
        'nav-tours': 'Danh Sách Tour',
        'nav-favorites': 'Tour Yêu Thích',
        'nav-login': 'Đăng Nhập',
        'nav-register': 'Đăng Nhập/Đăng Ký',
        'nav-admin': 'Trang Quản Trị',
        'nav-logout': 'Đăng Xuất',
        'nav-user': 'Người Dùng',
        
        // Hero Section
        'title': 'Khám Phá Thế Giới Cùng Chúng Tôi',
        'description': 'Tìm kiếm và đặt tour du lịch tuyệt vời nhất với giá cả hợp lý',
        'btn-view-tours': 'Xem Tour Ngay',
        
        // Tour List
        'tour-list-title': 'Danh Sách Tour',
        'search-placeholder': 'Tìm theo tên tour hoặc thời lượng...',
        'filter-location': 'Lọc Theo Địa Điểm',
        'filter-price': 'Lọc Theo Giá',
        'filter-all-location': 'Tất Cả Địa Điểm',
        'filter-all-price': 'Tất Cả Giá',
        'filter-price-under': 'Dưới 1 triệu',
        'filter-price-1-3': '1 - 3 triệu',
        'filter-price-3-5': '3 - 5 triệu',
        'filter-price-over': 'Trên 5 triệu',
        'btn-clear-filter': 'Xóa Lọc',
        
        // Favorites
        'favorites-title': 'Tour Yêu Thích Của Tôi',
        'favorites-empty': 'Bạn chưa có tour yêu thích nào. Hãy thêm tour vào danh sách yêu thích!',
        'btn-favorite': 'Yêu Thích',
        'btn-favorited': 'Đã Yêu Thích',
        
        // Tour Card
        'tour-duration': 'ngày',
        'btn-add-note': 'Thêm Ghi Chú',
        'btn-edit-note': 'Sửa Ghi Chú',
        'btn-delete': 'Xóa',
        
        // Theme
        'theme-light': 'Sáng',
        'theme-dark': 'Tối',
        
        // Common
        'loading': 'Đang tải...',
        'no-tours': 'Không có tour nào!',
        'search': 'Tìm Kiếm',
    }
};

// Lấy ngôn ngữ từ localStorage hoặc mặc định là tiếng Việt
let currentLanguage = localStorage.getItem('language') || 'vi';

// Hàm thiết lập ngôn ngữ
function setLanguage(lang) {
    currentLanguage = lang;
    localStorage.setItem('language', lang);
    
    // Cập nhật tất cả các phần tử có data-i18n
    document.querySelectorAll('[data-i18n]').forEach((el) => {
        const key = el.getAttribute('data-i18n');
        if (translations[lang] && translations[lang][key]) {
            // Nếu là input placeholder hoặc button với icon, chỉ cập nhật text
            if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                el.placeholder = translations[lang][key];
            } else if (el.tagName === 'BUTTON' && el.querySelector('i')) {
                // Giữ lại icon, chỉ cập nhật text
                const icon = el.querySelector('i');
                const span = el.querySelector('span');
                if (span) {
                    span.textContent = translations[lang][key];
                } else {
                    el.innerHTML = icon.outerHTML + ' ' + translations[lang][key];
                }
            } else {
                el.textContent = translations[lang][key];
            }
        }
    });
    
    // Trigger event để darkmode.js cập nhật label
    $(document).trigger('languageChanged');
    
    // Cập nhật placeholder
    const searchInput = document.getElementById('timKiemTour');
    if (searchInput) {
        searchInput.placeholder = translations[lang]['search-placeholder'] || '';
    }
    
    // Cập nhật select options
    updateSelectOptions(lang);
    
    // Cập nhật HTML lang attribute
    document.documentElement.setAttribute('lang', lang);
}

// Cập nhật các option trong select
function updateSelectOptions(lang) {
    const locationSelect = document.getElementById('locDiaDiem');
    if (locationSelect && locationSelect.options.length > 0) {
        locationSelect.options[0].text = translations[lang]['filter-all-location'];
    }
    
    const priceSelect = document.getElementById('locGia');
    if (priceSelect) {
        const priceOptions = priceSelect.options;
        if (priceOptions.length > 0) priceOptions[0].text = translations[lang]['filter-all-price'];
        if (priceOptions.length > 1) priceOptions[1].text = translations[lang]['filter-price-under'];
        if (priceOptions.length > 2) priceOptions[2].text = translations[lang]['filter-price-1-3'];
        if (priceOptions.length > 3) priceOptions[3].text = translations[lang]['filter-price-3-5'];
        if (priceOptions.length > 4) priceOptions[4].text = translations[lang]['filter-price-over'];
    }
}

// Khởi tạo khi DOM ready
$(document).ready(function() {
    const languageSelector = document.getElementById('language-selector');
    
    // Thiết lập ngôn ngữ ban đầu
    if (languageSelector) {
        languageSelector.value = currentLanguage;
        setLanguage(currentLanguage);
        
        // Lắng nghe sự kiện thay đổi
        languageSelector.addEventListener('change', (e) => {
            setLanguage(e.target.value);
        });
    } else {
        // Nếu chưa có selector, vẫn set ngôn ngữ
        setLanguage(currentLanguage);
    }
});
