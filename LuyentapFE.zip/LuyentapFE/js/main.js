// ============================================
// CẤU HÌNH MOCKAPI
// ============================================
const MOCKAPI_BASE_URL = 'https://66494e064032b1331beda92d.mockapi.io/api/v2';
const API_USERS = `${MOCKAPI_BASE_URL}/user`;
const API_TOURS = `${MOCKAPI_BASE_URL}/sanpham`;

// ============================================
// BIẾN TOÀN CỤC
// ============================================
let nguoiDungHienTai = null;
let danhSachTour = [];
let danhSachTourYeuThich = JSON.parse(localStorage.getItem('tourYeuThich')) || [];

// ============================================
// KHỞI TẠO ỨNG DỤNG
// ============================================
$(document).ready(function() {
    kiemTraDangNhap();
    khoiTaoSuKien();
    taiDanhSachTour();
    // Không gọi hienThiTourYeuThich() ở đây vì sẽ hiển thị khi user click vào menu
    
    // Lắng nghe sự kiện thay đổi ngôn ngữ để cập nhật lại tour cards
    $(document).on('languageChanged', function() {
        // Cập nhật lại danh sách tour nếu đang hiển thị
        if ($('#danhSachTour').is(':visible')) {
            hienThiDanhSachTourCards(danhSachTour);
        }
        // Cập nhật lại tour yêu thích nếu đang hiển thị
        if ($('#tourYeuThich').is(':visible')) {
            hienThiDanhSachTourYeuThich();
        }
    });
});

// ============================================
// KIỂM TRA ĐĂNG NHẬP
// ============================================
function kiemTraDangNhap() {
    const thongTinDangNhap = localStorage.getItem('thongTinDangNhap');
    if (thongTinDangNhap) {
        nguoiDungHienTai = JSON.parse(thongTinDangNhap);
        capNhatGiaoDienNguoiDung();
    }
}

// ============================================
// CẬP NHẬT GIAO DIỆN NGƯỜI DÙNG
// ============================================
function capNhatGiaoDienNguoiDung() {
    if (nguoiDungHienTai) {
        $('#navDangNhap').hide();
        $('#navDangKy').hide();
        $('#navNguoiDung').show();
        $('#navQuanLy').show();
        $('#tenNguoiDung').text(nguoiDungHienTai.name);
    } else {
        $('#navDangNhap').show();
        $('#navDangKy').show();
        $('#navNguoiDung').hide();
        $('#navQuanLy').hide();
    }
}

// ============================================
// KHỞI TẠO SỰ KIỆN
// ============================================
function khoiTaoSuKien() {
    // Navigation
    $('#navTrangChu').click(function(e) {
        e.preventDefault();
        hienThiTrangChu();
    });
    
    $('#navDanhSachTour').click(function(e) {
        e.preventDefault();
        hienThiDanhSachTour();
    });
    
    $('#navTourYeuThich').click(function(e) {
        e.preventDefault();
        hienThiTourYeuThich();
    });
    
    $('#navQuanLyTour').click(function(e) {
        e.preventDefault();
        hienThiDanhSachTour();
    });
    
    $('#btnXemTour').click(function() {
        hienThiDanhSachTour();
    });
    
    // Đăng xuất
    $('#btnDangXuat').click(function() {
        xuLyDangXuat();
    });
    
    // Tìm kiếm và lọc
    $('#timKiemTour').on('input', function() {
        locVaTimKiemTour();
    });
    
    $('#locDiaDiem').change(function() {
        locVaTimKiemTour();
    });
    
    $('#locGia').change(function() {
        locVaTimKiemTour();
    });
    
    $('#btnXoaLoc').click(function() {
        $('#timKiemTour').val('');
        $('#locDiaDiem').val('');
        $('#locGia').val('');
        locVaTimKiemTour();
    });
    
    // Ghi chú
    $('#btnLuuGhiChu').click(function() {
        luuGhiChuTourYeuThich();
    });
}

// ============================================
// HIỂN THỊ TRANG
// ============================================
function hienThiTrangChu() {
    $('#trangChu').show();
    $('#danhSachTour').hide();
    $('#tourYeuThich').hide();
}

function hienThiDanhSachTour() {
    $('#trangChu').hide();
    $('#danhSachTour').show();
    $('#tourYeuThich').hide();
    // Hiển thị filter khi xem danh sách tour
    $('.filter-card').show();
    taiDanhSachTour();
}

function hienThiTourYeuThich() {
    // Ẩn tất cả các section khác
    $('#trangChu').hide();
    $('#danhSachTour').hide();
    
    // Ẩn filter khi xem tour yêu thích
    $('.filter-card').hide();
    
    // Load lại dữ liệu tour yêu thích từ localStorage
    danhSachTourYeuThich = JSON.parse(localStorage.getItem('tourYeuThich')) || [];
    
    // Hiển thị section tour yêu thích
    $('#tourYeuThich').show();
    
    // Hiển thị danh sách tour yêu thích
    hienThiDanhSachTourYeuThich();
}

// ============================================
// XỬ LÝ ĐĂNG XUẤT
// ============================================
function xuLyDangXuat() {
    nguoiDungHienTai = null;
    localStorage.removeItem('thongTinDangNhap');
    capNhatGiaoDienNguoiDung();
    hienThiTrangChu();
    hienThiThongBaoThanhCong('Đã đăng xuất thành công!');
}

// ============================================
// TẢI DANH SÁCH TOUR
// ============================================
async function taiDanhSachTour() {
    hienThiLoading(true);
    
    try {
        const response = await $.ajax({
            url: API_TOURS,
            method: 'GET'
        });
        
        danhSachTour = response;
        hienThiDanhSachTourCards(danhSachTour);
        capNhatSelectDiaDiem();
    } catch (error) {
        console.error('Lỗi tải danh sách tour:', error);
        hienThiThongBaoLoi('', 'Không thể tải danh sách tour!');
    } finally {
        hienThiLoading(false);
    }
}

// ============================================
// HIỂN THỊ DANH SÁCH TOUR CARDS
// ============================================
function hienThiDanhSachTourCards(tours) {
    const container = $('#danhSachTourCards');
    container.empty();
    
    if (tours.length === 0) {
        container.html('<div class="col-12"><div class="alert alert-info">Không có tour nào!</div></div>');
        return;
    }
    
    tours.forEach((tour, index) => {
        const card = taoCardTour(tour, index);
        container.append(card);
    });
}

// ============================================
// TẠO CARD TOUR
// ============================================
function taoCardTour(tour, index) {
    const isYeuThich = danhSachTourYeuThich.some(t => t.id === tour.id);
    const giaFormatted = formatGia(tour.price);
    const lang = localStorage.getItem('language') || 'vi';
    const ngayTao = new Date(tour.createdAt).toLocaleDateString(lang === 'en' ? 'en-US' : 'vi-VN');
    const durationText = lang === 'en' ? 'days' : 'ngày';
    const favoriteText = isYeuThich ? (lang === 'en' ? 'Favorited' : 'Đã Yêu Thích') : (lang === 'en' ? 'Favorite' : 'Yêu Thích');
    
    // Tạo HTML cho ảnh tour
    const imageHtml = tour.image ? 
        `<div class="card-img-top-container">
            <img src="${tour.image}" class="card-img-top" alt="${tour.title}" onerror="this.src='https://via.placeholder.com/400x250/667eea/ffffff?text=Tour+Image'">
        </div>` : 
        `<div class="card-img-top-container">
            <div class="card-img-placeholder">
                <i class="bi bi-image"></i>
                <p>${lang === 'en' ? 'No Image' : 'Không có ảnh'}</p>
            </div>
        </div>`;
    
    return $(`
        <div class="col-md-6 col-lg-4 tour-card" style="animation-delay: ${index * 0.1}s">
            <div class="card h-100">
                ${imageHtml}
                <div class="card-body">
                    <h5 class="card-title">${tour.title}</h5>
                    <p class="card-text">
                        <i class="bi bi-geo-alt-fill text-primary"></i> 
                        <strong>${tour.destination}</strong>
                    </p>
                    <p class="card-text">${tour.description}</p>
                    <div class="gia-tour">${giaFormatted}</div>
                    <div>
                        <span class="thoi-luong">
                            <i class="bi bi-clock"></i> ${tour.duration} ${durationText}
                        </span>
                    </div>
                    <div class="mt-2">
                        <small class="text-muted">
                            <i class="bi bi-calendar"></i> ${ngayTao}
                        </small>
                    </div>
                    <div class="action-buttons">
                        <button class="btn btn-sm btn-yeu-thich ${isYeuThich ? 'active' : ''}" 
                                onclick="chuyenDoiYeuThich('${tour.id}')">
                            <i class="bi ${isYeuThich ? 'bi-heart-fill' : 'bi-heart'}"></i>
                            ${favoriteText}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `);
}

// ============================================
// CẬP NHẬT SELECT ĐỊA ĐIỂM
// ============================================
function capNhatSelectDiaDiem() {
    const select = $('#locDiaDiem');
    const diaDiemHienCo = [...new Set(danhSachTour.map(t => t.destination))];
    
    select.find('option:not(:first)').remove();
    
    diaDiemHienCo.forEach(diaDiem => {
        select.append(`<option value="${diaDiem}">${diaDiem}</option>`);
    });
}

// ============================================
// LỌC VÀ TÌM KIẾM TOUR
// ============================================
function locVaTimKiemTour() {
    const tuKhoa = $('#timKiemTour').val().toLowerCase();
    const diaDiem = $('#locDiaDiem').val();
    const gia = $('#locGia').val();
    
    let toursLoc = danhSachTour.filter(tour => {
        // Tìm kiếm theo tên hoặc thời lượng
        const timKiem = !tuKhoa || 
            tour.title.toLowerCase().includes(tuKhoa) || 
            tour.duration.toString().includes(tuKhoa);
        
        // Lọc theo địa điểm
        const locDiaDiem = !diaDiem || tour.destination === diaDiem;
        
        // Lọc theo giá
        let locGia = true;
        if (gia) {
            const [min, max] = gia.split('-').map(Number);
            locGia = tour.price >= min && tour.price <= max;
        }
        
        return timKiem && locDiaDiem && locGia;
    });
    
    hienThiDanhSachTourCards(toursLoc);
}

// ============================================
// CHUYỂN ĐỔI YÊU THÍCH
// ============================================
function chuyenDoiYeuThich(tourId) {
    const tour = danhSachTour.find(t => t.id === tourId);
    if (!tour) return;
    
    const index = danhSachTourYeuThich.findIndex(t => t.id === tourId);
    
    if (index > -1) {
        // Xóa khỏi yêu thích
        danhSachTourYeuThich.splice(index, 1);
        hienThiThongBaoThanhCong('Đã xóa khỏi danh sách yêu thích!');
    } else {
        // Thêm vào yêu thích
        danhSachTourYeuThich.push({
            id: tour.id,
            title: tour.title,
            destination: tour.destination,
            price: tour.price,
            duration: tour.duration,
            description: tour.description,
            image: tour.image || '',
            createdAt: tour.createdAt,
            ghiChu: ''
        });
        hienThiThongBaoThanhCong('Đã thêm vào danh sách yêu thích!');
    }
    
    localStorage.setItem('tourYeuThich', JSON.stringify(danhSachTourYeuThich));
    
    // Cập nhật lại danh sách tour
    taiDanhSachTour();
}

// ============================================
// HIỂN THỊ DANH SÁCH TOUR YÊU THÍCH
// ============================================
function hienThiDanhSachTourYeuThich() {
    const container = $('#danhSachTourYeuThich');
    const thongBao = $('#thongBaoKhongCoYeuThich');
    
    if (danhSachTourYeuThich.length === 0) {
        container.empty();
        thongBao.show();
        return;
    }
    
    thongBao.hide();
    container.empty();
    
    danhSachTourYeuThich.forEach((tour, index) => {
        const card = taoCardTourYeuThich(tour, index);
        container.append(card);
    });
}

// ============================================
// TẠO CARD TOUR YÊU THÍCH
// ============================================
function taoCardTourYeuThich(tour, index) {
    const giaFormatted = formatGia(tour.price);
    const lang = localStorage.getItem('language') || 'vi';
    const ngayTao = new Date(tour.createdAt).toLocaleDateString(lang === 'en' ? 'en-US' : 'vi-VN');
    const durationText = lang === 'en' ? 'days' : 'ngày';
    const noteText = tour.ghiChu ? (lang === 'en' ? 'Edit Note' : 'Sửa Ghi Chú') : (lang === 'en' ? 'Add Note' : 'Thêm Ghi Chú');
    const deleteText = lang === 'en' ? 'Delete' : 'Xóa';
    
    // Tạo HTML cho ảnh tour
    const imageHtml = tour.image ? 
        `<div class="card-img-top-container">
            <img src="${tour.image}" class="card-img-top" alt="${tour.title}" onerror="this.src='https://via.placeholder.com/400x250/667eea/ffffff?text=Tour+Image'">
        </div>` : 
        `<div class="card-img-top-container">
            <div class="card-img-placeholder">
                <i class="bi bi-image"></i>
                <p>${lang === 'en' ? 'No Image' : 'Không có ảnh'}</p>
            </div>
        </div>`;
    
    return $(`
        <div class="col-md-6 col-lg-4 tour-card favorite-tour-card" style="animation-delay: ${index * 0.1}s">
            <div class="card h-100">
                ${imageHtml}
                <div class="card-body">
                    <h5 class="card-title">${tour.title}</h5>
                    <p class="card-text">
                        <i class="bi bi-geo-alt-fill text-primary"></i> 
                        <strong>${tour.destination}</strong>
                    </p>
                    <p class="card-text">${tour.description}</p>
                    <div class="gia-tour">${giaFormatted}</div>
                    <div>
                        <span class="thoi-luong">
                            <i class="bi bi-clock"></i> ${tour.duration} ${durationText}
                        </span>
                    </div>
                    <div class="mt-2">
                        <small class="text-muted">
                            <i class="bi bi-calendar"></i> ${ngayTao}
                        </small>
                    </div>
                    ${tour.ghiChu ? `
                        <div class="ghi-chu-badge">
                            <i class="bi bi-sticky"></i> ${tour.ghiChu}
                        </div>
                    ` : ''}
                    <div class="action-buttons">
                        <button class="btn btn-sm btn-warning" onclick="moModalGhiChu('${tour.id}')">
                            <i class="bi bi-pencil"></i> ${noteText}
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="xoaTourYeuThich('${tour.id}')">
                            <i class="bi bi-trash"></i> ${deleteText}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `);
}

// ============================================
// MỞ MODAL GHI CHÚ
// ============================================
function moModalGhiChu(tourId) {
    const tour = danhSachTourYeuThich.find(t => t.id === tourId);
    if (!tour) return;
    
    $('#ghiChuTourId').val(tourId);
    $('#noiDungGhiChu').val(tour.ghiChu || '');
    $('#modalGhiChu').modal('show');
}

// ============================================
// LƯU GHI CHÚ TOUR YÊU THÍCH
// ============================================
function luuGhiChuTourYeuThich() {
    const tourId = $('#ghiChuTourId').val();
    const ghiChu = $('#noiDungGhiChu').val();
    
    const tour = danhSachTourYeuThich.find(t => t.id === tourId);
    if (tour) {
        tour.ghiChu = ghiChu;
        localStorage.setItem('tourYeuThich', JSON.stringify(danhSachTourYeuThich));
        $('#modalGhiChu').modal('hide');
        hienThiDanhSachTourYeuThich();
        hienThiThongBaoThanhCong('Đã lưu ghi chú!');
    }
}

// ============================================
// XÓA TOUR YÊU THÍCH
// ============================================
function xoaTourYeuThich(tourId) {
    if (!confirm('Bạn có chắc chắn muốn xóa tour này khỏi danh sách yêu thích?')) {
        return;
    }
    
    danhSachTourYeuThich = danhSachTourYeuThich.filter(t => t.id !== tourId);
    localStorage.setItem('tourYeuThich', JSON.stringify(danhSachTourYeuThich));
    hienThiDanhSachTourYeuThich();
    taiDanhSachTour(); // Cập nhật lại nút yêu thích
    hienThiThongBaoThanhCong('Đã xóa khỏi danh sách yêu thích!');
}

// Hàm này đã được định nghĩa ở trên (dòng 132), không cần định nghĩa lại

// ============================================
// ĐỊNH DẠNG GIÁ
// ============================================
function formatGia(gia) {
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(gia);
}

// ============================================
// HIỂN THỊ LOADING
// ============================================
function hienThiLoading(show) {
    if (show) {
        $('#loadingSpinner').fadeIn();
    } else {
        $('#loadingSpinner').fadeOut();
    }
}

// ============================================
// HIỂN THỊ THÔNG BÁO LỖI
// ============================================
function hienThiThongBaoLoi(id, message) {
    if (id) {
        $(`#${id}`).text(message).fadeIn();
        setTimeout(() => {
            $(`#${id}`).fadeOut();
        }, 3000);
    } else {
        alert(message);
    }
}

// ============================================
// HIỂN THỊ THÔNG BÁO THÀNH CÔNG
// ============================================
function hienThiThongBaoThanhCong(message) {
    // Tạo toast notification
    const toast = $(`
        <div class="toast-notification alert alert-success alert-dismissible fade show" role="alert" style="position: fixed; top: 80px; right: 20px; z-index: 10000; min-width: 300px; box-shadow: 0 5px 15px rgba(0,0,0,0.3);">
            <i class="bi bi-check-circle"></i> ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `);
    
    $('body').append(toast);
    
    setTimeout(() => {
        toast.fadeOut(() => toast.remove());
    }, 3000);
}

